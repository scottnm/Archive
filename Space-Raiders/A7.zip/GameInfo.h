#ifndef GAMEINFO_H_
#define GAMEINFO_H_

#define BOARDWIDTH 35
#define BOARDHEIGHT 20

#endif
